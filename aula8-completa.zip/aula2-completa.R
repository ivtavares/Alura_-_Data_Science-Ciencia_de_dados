1
1+1
3*8+2/5
(3*7)/4
numero <- (3*7)/4
numero
numero * 2
lista <- c(1, 2, 3, 4, 5, 6)
lista
lista * 2
aulas <- c(2, 4, 4, 6, 6, 6, 6, 8, 8, 10)
hist(aulas)